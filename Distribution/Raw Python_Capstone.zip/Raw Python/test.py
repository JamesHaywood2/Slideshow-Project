from re import T

import comm
import FileSupport as FP

from PIL import Image, ImageTk, ImageOps, ImageDraw
import tkinter as tk
import ttkbootstrap as tb
from ttkbootstrap.scrolled import ScrolledFrame
from ttkbootstrap.constants import *

import tkinter.font as tkFont


class TagBox(tb.Frame):
    """
    TagBox is a frame which will house several frames on top of each other.\n
    Each of those inner frames will have some TagButtons, atleast one. Whenever a TagButton is added to the TagBox, it will check if the current inner frame has enough space to house the new TagButton.\n
    If not, it will create a new inner frame and add the TagButton below the last one.
    """
    fontSize = 10
    xNormal = None
    xHover = None

    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        self.tagFrames: list[tb.Frame] = []
        self.tags: list[str] = []
        self.tagButtons: dict = {}
        self.tagFrame: tb.Frame = tb.Frame(self)
        self.tagFrame.pack(fill=X, expand=True)
        self.width = 0
        self.oldWidth = 0
        self.initialResize = True

        #Bind the resize event to the TagBox
        self.bind("<Configure>", self.resizeEvent)

        #Create the style 'TagButton.TButton' for the TagButtons
        style = tb.Style()
        style.configure('TagButton.TButton', font=('Arial', 10))
        TagBox.fontSize = int(style.configure('TagButton.TButton')['font'].split()[1])

        TagBox.xNormal = TagBox.draw_X(style.colors.get('primary'), 1)
        TagBox.xHover = TagBox.draw_X(style.colors.get('danger'), TagBox.fontSize)


    def resizeEvent(self, event):
        self.update_idletasks()
        self.width = self.winfo_width()
        #If the width has grown by atleast 30 pixels, refill the tagbox
        if self.width > self.oldWidth + 30:
            self.oldWidth = self.width
            self.fillTagBox()

    def addTag(self, tag: str):
        self.tags.append(tag)
        self.fillTagBox()

    def removeTag(self, tag: str):
        self.tags.remove(tag)
        self.fillTagBox()

    def fillTagBox(self):
        self.update()
        self.width = self.winfo_width()
        self.oldWidth = self.width
        
        #Destroy all the tagFrames and TagButtons
        [tagFrame.destroy() for tagFrame in self.tagFrames]
        self.tagFrames = []
        self.tagButtons = {}
        #Create a new tagFrame
        self.tagFrame = tb.Frame(self)
        self.tagFrame.pack(fill=X, expand=True, pady=2)
        self.tagFrames.append(self.tagFrame)
        self.tagFrame.update_idletasks()
        # print(f"TagFrame width: {self.tagFrame.winfo_width()}")

        self.spaceLeft = self.width - 2

        buttonPadX = 3
        #Add all the tags back
        # print(self.tags)
        for tag in self.tags:
            #Estimate the width of the tag
            tagWidth = self.estimateWidth(tag)
            
            #If the tag cannot fit in the current tagFrame, create a new one
            if tagWidth > self.spaceLeft:
                self.tagFrame = tb.Frame(self)
                self.tagFrame.pack(fill=X, expand=True, pady=2)
                self.tagFrames.append(self.tagFrame)
                self.tagFrame.update_idletasks()
                self.spaceLeft = self.width - 2

            #Create a new TagButton
            tagButton = self.TagButton(self.tagFrame, tag, style='TagButton.TButton', command=lambda x=tag: self.removeTag(x))
            tagButton.pack(side=LEFT, padx=buttonPadX)
            self.tagButtons[tag] = tagButton
            buttonWidth = tagButton.getWidth() + buttonPadX*2
            self.spaceLeft -= buttonWidth
            # print(f"{tag} width: {buttonWidth} estimated: {tagWidth} spaceLeft: {self.spaceLeft} | sL-W: {self.spaceLeft - buttonWidth}")


    def estimateWidth(self, tag):
        font = tkFont.Font()
        return font.measure(" " + tag + " ") + 3
    
    @staticmethod
    def draw_X(color: str, size=10):
        #Scale the x symbol to the font size
        x = Image.new('RGBA', (size, size), (255, 255, 255, 0))
        draw = ImageDraw.Draw(x)
        draw.line((0, 0, size, size), fill=color, width=2)
        draw.line((0, size, size, 0), fill=color, width=2)
        #Convert the image to a tkinter image
        x = ImageTk.PhotoImage(x)
        return x
    
        
    class TagButton(tb.Button):
        """
        TagButton is a button that will be used to display a tag.\n
        Whenever a TagButton is clicked it will remove itself and the tag it represents from the TagBox.
        It will have a little x symbol that will be styled to change when hovered over.
        """
        def __init__(self, master=None, tagText="None", **kw):
            super().__init__(master, **kw)
            self.tag = tagText
            self.config(text=self.tag)
            self.tagbox: TagBox = master.master

            self.config(image=TagBox.xNormal, compound=RIGHT)

            # self.config(image=self.xNormal, compound=RIGHT)
            self.bind("<Enter>", self.enter)
            self.bind("<Leave>", self.leave)

        def getWidth(self):
            self.update_idletasks()
            return self.winfo_width()
            
        def enter(self, event):
            self.config(image=TagBox.xHover, compound=RIGHT)

        def leave(self, event):
            self.config(image=TagBox.xNormal, compound=RIGHT)


        

root = tb.Window()
root.title('Test')
root.geometry('800x600')
root.resizable(False, False)

#root background color
root.config(bg='#0f0f0f')

style = tb.Style()

scrolledFrame = ScrolledFrame(root, autohide=True)
scrolledFrame.pack(fill=BOTH, expand=True, padx=50, pady=50)


tagBox = TagBox(scrolledFrame)
tags = ["Action", "Comedy", "Drama", "Horror", "Thriller", "Fantasy", "Animation", "Documentary", "Romantic Comedy", "Science Fiction", "Crime", "Mystery", "Adventure", "Family", "Musical", "War", "Western", "Historical", "Superhero", "Sports"]
tagBox.tags = tags
tagBox.pack(fill=X, expand=True)

root.mainloop()